
// This file is no longer required as per the new layout requirements.
export default () => null;
